// Util/FilePathAutoRename.h

#ifndef __FILEPATHAUTORENAME_H
#define __FILEPATHAUTORENAME_H

#include "Common/MyString.h"

bool AutoRenamePath(UString &fullProcessedPath);

#endif
