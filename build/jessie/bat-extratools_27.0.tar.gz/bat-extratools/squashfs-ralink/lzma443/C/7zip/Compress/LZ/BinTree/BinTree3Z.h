// BinTree3Z.h

#ifndef __BINTREE3Z_H
#define __BINTREE3Z_H

#define BT_NAMESPACE NBT3Z

#define HASH_ZIP

#include "BinTreeMain.h"

#undef HASH_ZIP

#undef BT_NAMESPACE

#endif
