// BinTree4b.h

#ifndef __BINTREE4B_H
#define __BINTREE4B_H

#undef BT_NAMESPACE
#define BT_NAMESPACE NBT4B

#define HASH_ARRAY_2
#define HASH_ARRAY_3
#define HASH_BIG

#include "BinTree.h"
#include "BinTreeMain.h"

#undef HASH_ARRAY_2
#undef HASH_ARRAY_3
#undef HASH_BIG

#endif
