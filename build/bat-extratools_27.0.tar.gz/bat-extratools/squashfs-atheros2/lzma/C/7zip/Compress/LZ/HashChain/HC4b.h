// HC4b.h

#ifndef __HC4B__H
#define __HC4B__H

#undef HC_NAMESPACE
#define HC_NAMESPACE NHC4b

#define HASH_ARRAY_2
#define HASH_ARRAY_3
#define HASH_BIG

#include "HC.h"
#include "HCMain.h"

#undef HASH_ARRAY_2
#undef HASH_ARRAY_3
#undef HASH_BIG

#endif

