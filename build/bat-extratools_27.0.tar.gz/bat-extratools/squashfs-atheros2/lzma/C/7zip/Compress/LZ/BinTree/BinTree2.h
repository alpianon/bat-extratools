// BinTree2.h

#ifndef __BINTREE2_H
#define __BINTREE2_H

#undef BT_NAMESPACE
#define BT_NAMESPACE NBT2

#include "BinTree.h"
#include "BinTreeMain.h"

#endif
