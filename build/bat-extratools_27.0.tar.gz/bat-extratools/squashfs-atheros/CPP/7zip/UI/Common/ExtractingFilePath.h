// ExtractingFilePath.h

#ifndef __EXTRACTINGFILEPATH_H
#define __EXTRACTINGFILEPATH_H

#include "Common/MyString.h"

void MakeCorrectPath(UStringVector &pathParts);

#endif
